import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#121212] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background gradient orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#6366f1] opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#8b5cf6] opacity-20 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-md mx-auto relative z-10">
        {/* Logo/Brand */}
        <div className="text-center mb-12">
          <h1 className="gradient-text mb-2">TuneTracker</h1>
          <p className="text-[#a0a0a0] text-sm">
            Project Management for Music Producers
          </p>
        </div>

        {/* Login Card - Glassmorphism */}
        <div className="glass rounded-[16px] p-8 shadow-2xl">
          <h2 className="mb-8 text-white">
            {isRegister ? 'Create Account' : 'Welcome Back'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Input */}
            <div className="space-y-2">
              <label htmlFor="email" className="block text-[#a0a0a0] text-sm font-medium">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] focus:border-transparent transition-all"
                placeholder="you@example.com"
                required
              />
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label htmlFor="password" className="block text-[#a0a0a0] text-sm font-medium">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] focus:border-transparent transition-all"
                placeholder="••••••••"
                required
              />
            </div>

            {/* Submit Button - Gradient */}
            <button
              type="submit"
              className="w-full gradient-primary text-white font-medium px-6 py-3 rounded-lg hover:opacity-90 transition-all shadow-lg hover:shadow-xl"
            >
              {isRegister ? 'Create Account' : 'Sign In'}
            </button>

            {/* Toggle Link */}
            <div className="text-center pt-4">
              <button
                type="button"
                onClick={() => setIsRegister(!isRegister)}
                className="text-sm text-[#a0a0a0] hover:text-white transition-colors"
              >
                {isRegister ? (
                  <>
                    Already have an account?{' '}
                    <span className="gradient-text font-medium">Sign In</span>
                  </>
                ) : (
                  <>
                    Don't have an account?{' '}
                    <span className="gradient-text font-medium">Create One</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-[#666] text-xs">
            Built for producers, by producers
          </p>
        </div>
      </div>
    </div>
  );
}
