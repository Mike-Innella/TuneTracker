import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function ProjectForm() {
  const { projectId } = useParams();
  const { projects, addProject, updateProject } = useApp();
  const navigate = useNavigate();

  const existingProject = projectId ? projects.find(p => p.id === projectId) : null;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(false);

  useEffect(() => {
    if (existingProject) {
      setTitle(existingProject.title);
      setDescription(existingProject.description);
      setIsPublic(existingProject.isPublic);
    }
  }, [existingProject]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (projectId && existingProject) {
      updateProject(projectId, { title, description, isPublic });
    } else {
      addProject({ title, description, isPublic });
    }
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-[#121212]">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate('/dashboard')}
            className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2"
          >
            <span>←</span>
            <span>Back</span>
          </button>
          <h1 className="gradient-text">
            {projectId ? 'Edit Project' : 'New Project'}
          </h1>
        </div>

        {/* Form Card */}
        <div className="glass rounded-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Project Title */}
            <div className="space-y-3">
              <label htmlFor="title" className="block text-[#a0a0a0] text-sm font-medium">
                Project Title
              </label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] focus:border-transparent transition-all"
                placeholder="e.g. Summer EP 2024"
                required
              />
            </div>

            {/* Description */}
            <div className="space-y-3">
              <label htmlFor="description" className="block text-[#a0a0a0] text-sm font-medium">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] focus:border-transparent transition-all resize-none"
                placeholder="Describe your project..."
                rows={5}
                required
              />
            </div>

            {/* Visibility Toggle */}
            <div className="space-y-3">
              <label className="block text-[#a0a0a0] text-sm font-medium">
                Visibility
              </label>
              <div className="glass-strong rounded-lg p-5 flex items-center justify-between">
                <div>
                  <div className="text-white font-medium mb-1">
                    {isPublic ? 'Public Project' : 'Private Project'}
                  </div>
                  <div className="text-[#666] text-sm">
                    {isPublic
                      ? 'Anyone with the link can view this project'
                      : 'Only you can view this project'}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsPublic(!isPublic)}
                  className={`relative w-14 h-7 rounded-full transition-all ${
                    isPublic
                      ? 'bg-gradient-to-r from-[#6366f1] to-[#8b5cf6]'
                      : 'bg-[rgba(255,255,255,0.1)]'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-lg transition-all ${
                      isPublic ? 'right-1' : 'left-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="flex-1 bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-white font-medium px-6 py-3 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 gradient-primary text-white font-medium px-6 py-3 rounded-lg hover:opacity-90 transition-all shadow-lg hover:shadow-xl"
              >
                {projectId ? 'Save Changes' : 'Create Project'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
