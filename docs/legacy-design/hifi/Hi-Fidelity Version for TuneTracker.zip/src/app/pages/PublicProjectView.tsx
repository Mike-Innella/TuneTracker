import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function PublicProjectView() {
  const { projectId } = useParams();
  const { projects, tracks, comments, likes, ratings, currentUserId, addComment, toggleLike, addRating } = useApp();
  const navigate = useNavigate();

  const project = projects.find(p => p.id === projectId);
  const projectTracks = tracks.filter(t => t.projectId === projectId);
  const projectComments = comments.filter(c => c.projectId === projectId);
  const projectLikes = likes.filter(l => l.projectId === projectId);
  const userLiked = projectLikes.some(l => l.userId === currentUserId);
  const userRating = ratings.find(r => r.projectId === projectId && r.userId === currentUserId);

  const [commentText, setCommentText] = useState('');
  const [selectedRating, setSelectedRating] = useState<number>(userRating?.rating || 0);

  const handleAddComment = () => {
    if (commentText.trim() && projectId) {
      addComment({
        projectId,
        author: 'Current User',
        content: commentText,
      });
      setCommentText('');
    }
  };

  const handleRating = (rating: number) => {
    if (projectId) {
      setSelectedRating(rating);
      addRating(projectId, rating);
    }
  };

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      {/* Header */}
      <div className="glass-strong border-b border-[rgba(255,255,255,0.1)] backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-3">
            <button
              onClick={() => navigate(`/project/${projectId}/board`)}
              className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2"
            >
              <span>←</span>
              <span>Back</span>
            </button>
            <div className="bg-[rgba(99,102,241,0.2)] text-[#a78bfa] px-3 py-1 rounded-full text-xs font-medium">
              🌐 Public View
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        {/* Project Header */}
        <div className="glass rounded-xl p-8">
          <h1 className="gradient-text mb-4">{project.title}</h1>
          <p className="text-[#a0a0a0] leading-relaxed">{project.description}</p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4">
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1">{projectTracks.length}</div>
            <div className="text-[#666] text-sm">Tracks</div>
          </div>
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1">{projectLikes.length}</div>
            <div className="text-[#666] text-sm">Likes</div>
          </div>
          <div className="glass rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1">{projectComments.length}</div>
            <div className="text-[#666] text-sm">Comments</div>
          </div>
        </div>

        {/* Tracks List */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-white font-semibold mb-6">Tracks</h2>
          <div className="space-y-3">
            {projectTracks.map((track) => (
              <div
                key={track.id}
                className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.1)] transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-white font-medium mb-1">{track.title}</h3>
                    {track.bpm && (
                      <div className="flex items-center gap-3 text-xs text-[#a0a0a0]">
                        <span className="bg-[rgba(255,255,255,0.05)] px-2 py-1 rounded">
                          {track.bpm} BPM
                        </span>
                        <span className="bg-[rgba(255,255,255,0.05)] px-2 py-1 rounded">
                          {track.key}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="bg-gradient-to-br from-[#6366f1]/20 to-[#8b5cf6]/10 px-3 py-1 rounded-full">
                    <span className="text-white text-sm">{track.stage}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Engagement Section */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-white font-semibold mb-6">Feedback</h2>
          
          {/* Like Button */}
          <div className="flex items-center justify-between mb-6 pb-6 border-b border-[rgba(255,255,255,0.05)]">
            <div className="text-[#a0a0a0]">
              {projectLikes.length} {projectLikes.length === 1 ? 'like' : 'likes'}
            </div>
            <button
              onClick={() => projectId && toggleLike(projectId)}
              className={`px-6 py-2 rounded-lg font-medium transition-all ${
                userLiked
                  ? 'gradient-primary text-white shadow-lg'
                  : 'bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-white'
              }`}
            >
              {userLiked ? '❤️ Liked' : '🤍 Like'}
            </button>
          </div>

          {/* Rating */}
          <div className="mb-6">
            <h3 className="text-white text-sm font-medium mb-4">Your Rating</h3>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  onClick={() => handleRating(rating)}
                  className={`w-12 h-12 rounded-lg font-medium transition-all ${
                    rating <= selectedRating
                      ? 'gradient-primary text-white shadow-lg'
                      : 'bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#666] hover:text-white'
                  }`}
                >
                  {rating}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-white font-semibold mb-6">
            Comments ({projectComments.length})
          </h2>

          {/* Add Comment */}
          <div className="mb-6 bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.1)]">
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] resize-none mb-3"
              placeholder="Share your thoughts..."
              rows={4}
            />
            <button
              onClick={handleAddComment}
              className="w-full gradient-primary text-white font-medium px-6 py-3 rounded-lg hover:opacity-90 transition-all"
            >
              Post Comment
            </button>
          </div>

          {/* Comments List */}
          <div className="space-y-4">
            {projectComments.length === 0 ? (
              <div className="text-center py-8 text-[#666]">
                <p className="text-sm">No comments yet</p>
                <p className="text-xs mt-2">Be the first to share your thoughts</p>
              </div>
            ) : (
              projectComments.map((comment) => (
                <div
                  key={comment.id}
                  className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)]"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-white text-sm font-medium">{comment.author}</span>
                    <span className="text-[#666] text-xs">{comment.date}</span>
                  </div>
                  <p className="text-[#a0a0a0] text-sm leading-relaxed">{comment.content}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
