import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp, Stage } from '../context/AppContext';

const stages: Stage[] = ['Idea', 'Draft', 'Mix', 'Master', 'Released'];

const stageColors = {
  'Idea': 'from-[#6366f1]/20 to-[#6366f1]/10',
  'Draft': 'from-[#8b5cf6]/20 to-[#8b5cf6]/10',
  'Mix': 'from-[#a855f7]/20 to-[#a855f7]/10',
  'Master': 'from-[#c026d3]/20 to-[#c026d3]/10',
  'Released': 'from-[#10b981]/20 to-[#10b981]/10',
};

export default function ProjectBoard() {
  const { projectId } = useParams();
  const { projects, tracks, addTrack, updateTrack } = useApp();
  const navigate = useNavigate();

  const project = projects.find(p => p.id === projectId);
  const projectTracks = tracks.filter(t => t.projectId === projectId);

  const [showAddTrack, setShowAddTrack] = useState<Stage | null>(null);
  const [newTrackTitle, setNewTrackTitle] = useState('');
  const [dragOverStage, setDragOverStage] = useState<Stage | null>(null);

  const handleAddTrack = (stage: Stage) => {
    if (newTrackTitle.trim() && projectId) {
      addTrack({
        title: newTrackTitle,
        stage,
        projectId,
      });
      setNewTrackTitle('');
      setShowAddTrack(null);
    }
  };

  const handleDragStart = (e: React.DragEvent, trackId: string) => {
    e.dataTransfer.setData('trackId', trackId);
  };

  const handleDrop = (e: React.DragEvent, stage: Stage) => {
    e.preventDefault();
    setDragOverStage(null);
    const trackId = e.dataTransfer.getData('trackId');
    updateTrack(trackId, { stage });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDragEnter = (stage: Stage) => {
    setDragOverStage(stage);
  };

  const handleDragLeave = () => {
    setDragOverStage(null);
  };

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      {/* Header */}
      <div className="glass-strong border-b border-[rgba(255,255,255,0.1)] sticky top-0 z-20 backdrop-blur-xl">
        <div className="max-w-[1600px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2"
              >
                <span>←</span>
                <span>Back</span>
              </button>
              <div>
                <h1 className="gradient-text">{project.title}</h1>
                <p className="text-[#666] text-sm mt-1">
                  {projectTracks.length} {projectTracks.length === 1 ? 'track' : 'tracks'}
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate(`/project/${projectId}/public`)}
              className="gradient-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all text-sm font-medium"
            >
              Public View
            </button>
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="overflow-x-auto">
        <div className="inline-flex min-w-full p-6 gap-4">
          {stages.map((stage) => {
            const stageTracks = projectTracks.filter(t => t.stage === stage);
            const isDraggedOver = dragOverStage === stage;

            return (
              <div
                key={stage}
                className="w-80 flex-shrink-0"
                onDrop={(e) => handleDrop(e, stage)}
                onDragOver={handleDragOver}
                onDragEnter={() => handleDragEnter(stage)}
                onDragLeave={handleDragLeave}
              >
                {/* Column Header */}
                <div className={`glass rounded-xl p-4 mb-4 transition-all ${
                  isDraggedOver ? 'ring-2 ring-[#6366f1] bg-[rgba(99,102,241,0.1)]' : ''
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="text-white font-semibold">{stage}</h2>
                    <div className="bg-gradient-to-br ${stageColors[stage]} px-3 py-1 rounded-full">
                      <span className="text-white text-sm font-medium">
                        {stageTracks.length}
                      </span>
                    </div>
                  </div>
                  <div className="text-[#666] text-xs">
                    {stageTracks.length === 0 ? 'No tracks' : 
                     stageTracks.length === 1 ? '1 track' : `${stageTracks.length} tracks`}
                  </div>
                </div>

                {/* Track Cards */}
                <div className="space-y-3 min-h-[300px]">
                  {stageTracks.map((track) => (
                    <div
                      key={track.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, track.id)}
                      onClick={() => navigate(`/project/${projectId}/track/${track.id}`)}
                      className="glass rounded-lg p-4 cursor-move hover:bg-[rgba(30,30,35,0.9)] transition-all group border border-transparent hover:border-[rgba(99,102,241,0.5)]"
                    >
                      <h3 className="text-white font-medium mb-2 group-hover:gradient-text transition-all">
                        {track.title}
                      </h3>
                      {track.bpm && (
                        <div className="flex items-center gap-3 text-xs text-[#a0a0a0]">
                          <span className="bg-[rgba(255,255,255,0.05)] px-2 py-1 rounded">
                            {track.bpm} BPM
                          </span>
                          <span className="bg-[rgba(255,255,255,0.05)] px-2 py-1 rounded">
                            {track.key}
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Add Track Button */}
                <div className="mt-4">
                  {showAddTrack === stage ? (
                    <div className="glass rounded-lg p-4 space-y-3">
                      <input
                        type="text"
                        value={newTrackTitle}
                        onChange={(e) => setNewTrackTitle(e.target.value)}
                        className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-3 py-2 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] text-sm"
                        placeholder="Track title..."
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddTrack(stage);
                          if (e.key === 'Escape') setShowAddTrack(null);
                        }}
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleAddTrack(stage)}
                          className="flex-1 gradient-primary text-white px-3 py-2 rounded-lg text-sm font-medium hover:opacity-90 transition-all"
                        >
                          Add
                        </button>
                        <button
                          onClick={() => setShowAddTrack(null)}
                          className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-3 py-2 rounded-lg text-sm transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowAddTrack(stage)}
                      className="w-full bg-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.07)] border border-[rgba(255,255,255,0.1)] hover:border-[rgba(99,102,241,0.5)] text-[#a0a0a0] hover:text-white px-4 py-3 rounded-lg transition-all text-sm font-medium flex items-center justify-center gap-2"
                    >
                      <span className="text-lg font-light">+</span>
                      <span>Add Track</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
