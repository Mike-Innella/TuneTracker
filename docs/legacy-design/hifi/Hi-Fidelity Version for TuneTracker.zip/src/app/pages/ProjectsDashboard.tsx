import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';

export default function ProjectsDashboard() {
  const { projects, logout, tracks } = useApp();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getProjectTrackCount = (projectId: string) => {
    return tracks.filter(t => t.projectId === projectId).length;
  };

  return (
    <div className="min-h-screen bg-[#121212]">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <h1 className="gradient-text mb-2">My Projects</h1>
            <p className="text-[#a0a0a0] text-sm">
              {projects.length} {projects.length === 1 ? 'project' : 'projects'}
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all text-sm font-medium"
          >
            Sign Out
          </button>
        </div>

        {/* New Project Button */}
        <button
          onClick={() => navigate('/project/new')}
          className="w-full gradient-primary text-white font-semibold px-6 py-4 rounded-xl mb-8 hover:opacity-90 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
        >
          <span className="text-2xl font-light">+</span>
          <span>New Project</span>
        </button>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              onClick={() => navigate(`/project/${project.id}/board`)}
              className="glass rounded-xl p-6 cursor-pointer hover:bg-[rgba(30,30,35,0.9)] transition-all group"
            >
              {/* Project Header */}
              <div className="mb-4">
                <h3 className="text-white mb-2 group-hover:gradient-text transition-all">
                  {project.title}
                </h3>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      project.isPublic
                        ? 'bg-[rgba(99,102,241,0.2)] text-[#a78bfa]'
                        : 'bg-[rgba(255,255,255,0.05)] text-[#a0a0a0]'
                    }`}
                  >
                    {project.isPublic ? '🌐 Public' : '🔒 Private'}
                  </span>
                </div>
              </div>

              {/* Project Meta */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#a0a0a0]">Tracks</span>
                  <span className="text-white font-medium">
                    {getProjectTrackCount(project.id)}
                  </span>
                </div>
                <div className="h-px bg-[rgba(255,255,255,0.05)]"></div>
                <div className="text-xs text-[#666]">
                  Updated {project.lastUpdated}
                </div>
              </div>

              {/* Action indicator */}
              <div className="flex items-center justify-between pt-4 border-t border-[rgba(255,255,255,0.05)]">
                <span className="text-sm text-[#a0a0a0] group-hover:gradient-text transition-all">
                  Open Project
                </span>
                <span className="text-[#a0a0a0] group-hover:text-white transition-colors">
                  →
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {projects.length === 0 && (
          <div className="glass rounded-xl p-12 text-center">
            <p className="text-[#a0a0a0] mb-4">No projects yet</p>
            <p className="text-sm text-[#666]">
              Create your first project to start tracking your music production
            </p>
          </div>
        )}
      </div>
    </div>
  );
}