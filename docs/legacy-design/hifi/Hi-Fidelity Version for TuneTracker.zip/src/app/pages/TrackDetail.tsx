import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function TrackDetail() {
  const { projectId, trackId } = useParams();
  const { tracks, sessionLogs, notes, addSessionLog, addNote } = useApp();
  const navigate = useNavigate();

  const track = tracks.find(t => t.id === trackId);
  const trackLogs = sessionLogs.filter(l => l.trackId === trackId);
  const trackNotes = notes.filter(n => n.trackId === trackId);

  const [showAddLog, setShowAddLog] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [logContent, setLogContent] = useState('');
  const [noteContent, setNoteContent] = useState('');

  const handleAddLog = () => {
    if (logContent.trim() && trackId) {
      addSessionLog({ trackId, content: logContent });
      setLogContent('');
      setShowAddLog(false);
    }
  };

  const handleAddNote = () => {
    if (noteContent.trim() && trackId) {
      addNote({ trackId, content: noteContent });
      setNoteContent('');
      setShowAddNote(false);
    }
  };

  if (!track) {
    return <div>Track not found</div>;
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      {/* Header */}
      <div className="glass-strong border-b border-[rgba(255,255,255,0.1)] sticky top-0 z-10 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <button
            onClick={() => navigate(`/project/${projectId}/board`)}
            className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2 mb-3"
          >
            <span>←</span>
            <span>Back to Board</span>
          </button>
          <h1 className="gradient-text">{track.title}</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        {/* Track Metadata Card */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-semibold">Track Details</h2>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)]">
              <div className="text-[#666] text-xs mb-2 uppercase tracking-wide">Status</div>
              <div className="text-white font-medium">{track.stage}</div>
            </div>
            {track.bpm && (
              <div className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)]">
                <div className="text-[#666] text-xs mb-2 uppercase tracking-wide">BPM</div>
                <div className="text-white font-medium">{track.bpm}</div>
              </div>
            )}
            {track.key && (
              <div className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)]">
                <div className="text-[#666] text-xs mb-2 uppercase tracking-wide">Key</div>
                <div className="text-white font-medium">{track.key}</div>
              </div>
            )}
          </div>
        </div>

        {/* Session Logs Section */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-semibold">Session Logs</h2>
            <button
              onClick={() => setShowAddLog(!showAddLog)}
              className="gradient-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all text-sm font-medium flex items-center gap-2"
            >
              <span className="text-lg font-light">+</span>
              <span>Add Log</span>
            </button>
          </div>

          {showAddLog && (
            <div className="mb-6 bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.1)]">
              <textarea
                value={logContent}
                onChange={(e) => setLogContent(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] resize-none"
                placeholder="What did you work on in this session?"
                rows={4}
              />
              <div className="flex gap-3 mt-3">
                <button
                  onClick={handleAddLog}
                  className="flex-1 gradient-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all text-sm font-medium"
                >
                  Save Log
                </button>
                <button
                  onClick={() => setShowAddLog(false)}
                  className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {trackLogs.length === 0 ? (
              <div className="text-center py-8 text-[#666]">
                <p className="text-sm">No session logs yet</p>
                <p className="text-xs mt-2">Track your progress and document your workflow</p>
              </div>
            ) : (
              trackLogs.map((log) => (
                <div
                  key={log.id}
                  className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.1)] transition-all"
                >
                  <p className="text-white text-sm mb-2">{log.content}</p>
                  <p className="text-[#666] text-xs">{log.date}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Notes Section */}
        <div className="glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-semibold">Notes for Later</h2>
            <button
              onClick={() => setShowAddNote(!showAddNote)}
              className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-white px-4 py-2 rounded-lg hover:border-[rgba(99,102,241,0.5)] transition-all text-sm font-medium flex items-center gap-2"
            >
              <span className="text-lg font-light">+</span>
              <span>Add Note</span>
            </button>
          </div>

          {showAddNote && (
            <div className="mb-6 bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.1)]">
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                className="w-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.15)] rounded-lg px-4 py-3 text-white placeholder-[#666] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.5)] resize-none"
                placeholder="Ideas, reminders, or things to try..."
                rows={4}
              />
              <div className="flex gap-3 mt-3">
                <button
                  onClick={handleAddNote}
                  className="flex-1 gradient-primary text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all text-sm font-medium"
                >
                  Save Note
                </button>
                <button
                  onClick={() => setShowAddNote(false)}
                  className="bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] border border-[rgba(255,255,255,0.1)] text-[#a0a0a0] hover:text-white px-4 py-2 rounded-lg transition-all text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {trackNotes.length === 0 ? (
              <div className="text-center py-8 text-[#666]">
                <p className="text-sm">No notes yet</p>
                <p className="text-xs mt-2">Capture ideas and reminders for this track</p>
              </div>
            ) : (
              trackNotes.map((note) => (
                <div
                  key={note.id}
                  className="bg-[rgba(255,255,255,0.03)] rounded-lg p-4 border border-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.1)] transition-all"
                >
                  <p className="text-white text-sm">{note.content}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
