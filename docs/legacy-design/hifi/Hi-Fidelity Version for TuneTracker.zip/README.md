
  # Hi-Fidelity Version for TuneTracker

  This is a code bundle for Hi-Fidelity Version for TuneTracker. The original project is available at https://www.figma.com/design/Sd6JaeXM1ZklDP8HbOtCmN/Hi-Fidelity-Version-for-TuneTracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  