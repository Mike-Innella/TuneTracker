import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import ProjectsDashboard from "./pages/ProjectsDashboard";
import ProjectForm from "./pages/ProjectForm";
import ProjectBoard from "./pages/ProjectBoard";
import TrackDetail from "./pages/TrackDetail";
import PublicProjectView from "./pages/PublicProjectView";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/dashboard",
    Component: ProjectsDashboard,
  },
  {
    path: "/project/new",
    Component: ProjectForm,
  },
  {
    path: "/project/:projectId/edit",
    Component: ProjectForm,
  },
  {
    path: "/project/:projectId/board",
    Component: ProjectBoard,
  },
  {
    path: "/project/:projectId/track/:trackId",
    Component: TrackDetail,
  },
  {
    path: "/project/:projectId/public",
    Component: PublicProjectView,
  },
]);