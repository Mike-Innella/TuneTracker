import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function PublicProjectView() {
  const { projectId } = useParams();
  const { projects, tracks, comments, likes, ratings, currentUserId, addComment, toggleLike, addRating } = useApp();
  const navigate = useNavigate();

  const project = projects.find(p => p.id === projectId);
  const projectTracks = tracks.filter(t => t.projectId === projectId);
  const projectComments = comments.filter(c => c.projectId === projectId);
  const projectLikes = likes.filter(l => l.projectId === projectId);
  const userLiked = projectLikes.some(l => l.userId === currentUserId);
  const userRating = ratings.find(r => r.projectId === projectId && r.userId === currentUserId);

  const [commentText, setCommentText] = useState('');
  const [selectedRating, setSelectedRating] = useState<number>(userRating?.rating || 0);

  const handleAddComment = () => {
    if (commentText.trim() && projectId) {
      addComment({
        projectId,
        author: 'Current User',
        content: commentText,
      });
      setCommentText('');
    }
  };

  const handleRating = (rating: number) => {
    if (projectId) {
      setSelectedRating(rating);
      addRating(projectId, rating);
    }
  };

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="w-full max-w-[390px] mx-auto bg-white min-h-screen border-x-2 border-neutral-300">
        {/* Header */}
        <div className="border-b-2 border-neutral-800 p-4">
          <div className="flex items-center gap-3 mb-2">
            <button
              onClick={() => navigate(`/project/${projectId}/board`)}
              className="border border-neutral-400 px-3 py-1 text-xs uppercase"
            >
              ← Back
            </button>
          </div>
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-2">
            <span className="text-xs uppercase tracking-wide">Public Project View (Read-Only)</span>
          </div>
        </div>

        {/* Project Info */}
        <div className="p-4 border-b border-neutral-300">
          <h1 className="text-lg uppercase tracking-wide mb-3">{project.title}</h1>
          <div className="border border-neutral-300 p-3 bg-neutral-50">
            <p className="text-sm">{project.description}</p>
          </div>
        </div>

        {/* Track List */}
        <div className="p-4 border-b border-neutral-300">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3">
            <h2 className="text-xs uppercase tracking-wide">Tracks ({projectTracks.length})</h2>
          </div>
          <div className="space-y-2">
            {projectTracks.map((track) => (
              <div key={track.id} className="border border-neutral-400 p-3 flex justify-between items-center">
                <div>
                  <div className="text-sm uppercase">{track.title}</div>
                  {track.bpm && (
                    <div className="text-xs text-neutral-600 mt-1">
                      {track.bpm} BPM | {track.key}
                    </div>
                  )}
                </div>
                <div className="border border-neutral-400 px-2 py-1 text-xs uppercase bg-neutral-100">
                  {track.stage}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Likes */}
        <div className="p-4 border-b border-neutral-300">
          <div className="flex items-center justify-between">
            <div className="text-sm">
              <span className="uppercase tracking-wide">Likes:</span> {projectLikes.length}
            </div>
            <button
              onClick={() => projectId && toggleLike(projectId)}
              className={`border-2 px-4 py-2 text-xs uppercase ${
                userLiked
                  ? 'border-neutral-800 bg-neutral-800 text-white'
                  : 'border-neutral-400 bg-white'
              }`}
            >
              {userLiked ? 'Liked' : 'Like'}
            </button>
          </div>
        </div>

        {/* Rating */}
        <div className="p-4 border-b border-neutral-300">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3">
            <h2 className="text-xs uppercase tracking-wide">Your Rating</h2>
          </div>
          <div className="flex gap-2 justify-center">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => handleRating(rating)}
                className={`w-10 h-10 border-2 text-sm ${
                  rating <= selectedRating
                    ? 'border-neutral-800 bg-neutral-800 text-white'
                    : 'border-neutral-400 bg-white'
                }`}
              >
                {rating}
              </button>
            ))}
          </div>
        </div>

        {/* Comments */}
        <div className="p-4">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3">
            <h2 className="text-xs uppercase tracking-wide">Comments ({projectComments.length})</h2>
          </div>

          {/* Add Comment */}
          <div className="mb-4 space-y-2">
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              className="w-full border-2 border-neutral-800 px-3 py-2 text-sm h-20"
              placeholder="Add a comment..."
            />
            <button
              onClick={handleAddComment}
              className="w-full border border-neutral-800 bg-neutral-800 text-white px-3 py-2 text-xs uppercase"
            >
              Post Comment
            </button>
          </div>

          {/* Comments List */}
          <div className="space-y-3">
            {projectComments.length === 0 ? (
              <div className="border border-neutral-300 p-3 text-sm text-neutral-500 text-center">
                No comments yet
              </div>
            ) : (
              projectComments.map((comment) => (
                <div key={comment.id} className="border border-neutral-400 p-3">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs uppercase tracking-wide">{comment.author}</span>
                    <span className="text-xs text-neutral-600">{comment.date}</span>
                  </div>
                  <div className="text-sm">{comment.content}</div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Annotation */}
        <div className="p-4 border-t border-neutral-300 mt-8">
          <p className="text-xs text-neutral-500 text-center">
            [WIREFRAME] Public Project View
          </p>
        </div>
      </div>
    </div>
  );
}