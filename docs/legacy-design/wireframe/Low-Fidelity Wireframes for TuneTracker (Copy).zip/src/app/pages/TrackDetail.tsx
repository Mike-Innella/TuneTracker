import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function TrackDetail() {
  const { projectId, trackId } = useParams();
  const { tracks, sessionLogs, notes, addSessionLog, addNote } = useApp();
  const navigate = useNavigate();

  const track = tracks.find(t => t.id === trackId);
  const trackLogs = sessionLogs.filter(l => l.trackId === trackId);
  const trackNotes = notes.filter(n => n.trackId === trackId);

  const [showAddLog, setShowAddLog] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [logContent, setLogContent] = useState('');
  const [noteContent, setNoteContent] = useState('');

  const handleAddLog = () => {
    if (logContent.trim() && trackId) {
      addSessionLog({ trackId, content: logContent });
      setLogContent('');
      setShowAddLog(false);
    }
  };

  const handleAddNote = () => {
    if (noteContent.trim() && trackId) {
      addNote({ trackId, content: noteContent });
      setNoteContent('');
      setShowAddNote(false);
    }
  };

  if (!track) {
    return <div>Track not found</div>;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="w-full max-w-[390px] mx-auto bg-white min-h-screen border-x-2 border-neutral-300">
        {/* Header */}
        <div className="border-b-2 border-neutral-800 p-4">
          <div className="flex items-center gap-3 mb-2">
            <button
              onClick={() => navigate(`/project/${projectId}/board`)}
              className="border border-neutral-400 px-3 py-1 text-xs uppercase"
            >
              ← Back
            </button>
          </div>
          <h1 className="text-lg uppercase tracking-wide">{track.title}</h1>
        </div>

        {/* Track Metadata */}
        <div className="p-4 border-b border-neutral-300">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3">
            <h2 className="text-xs uppercase tracking-wide">Track Metadata</h2>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-neutral-200 pb-2">
              <span className="text-neutral-600">Status:</span>
              <span className="uppercase">{track.stage}</span>
            </div>
            {track.bpm && (
              <div className="flex justify-between border-b border-neutral-200 pb-2">
                <span className="text-neutral-600">BPM:</span>
                <span>{track.bpm}</span>
              </div>
            )}
            {track.key && (
              <div className="flex justify-between border-b border-neutral-200 pb-2">
                <span className="text-neutral-600">Key:</span>
                <span>{track.key}</span>
              </div>
            )}
          </div>
        </div>

        {/* Session Logs */}
        <div className="p-4 border-b border-neutral-300">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3 flex justify-between items-center">
            <h2 className="text-xs uppercase tracking-wide">Session Logs</h2>
            <button
              onClick={() => setShowAddLog(!showAddLog)}
              className="text-xs uppercase underline"
            >
              + Add
            </button>
          </div>

          {showAddLog && (
            <div className="mb-3 space-y-2">
              <textarea
                value={logContent}
                onChange={(e) => setLogContent(e.target.value)}
                className="w-full border-2 border-neutral-800 px-3 py-2 text-sm h-20"
                placeholder="Enter session log..."
              />
              <div className="flex gap-2">
                <button
                  onClick={handleAddLog}
                  className="flex-1 border border-neutral-800 bg-neutral-800 text-white px-3 py-1 text-xs uppercase"
                >
                  Save
                </button>
                <button
                  onClick={() => setShowAddLog(false)}
                  className="border border-neutral-400 px-3 py-1 text-xs uppercase"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {trackLogs.length === 0 ? (
              <div className="border border-neutral-300 p-3 text-sm text-neutral-500 text-center">
                No session logs yet
              </div>
            ) : (
              trackLogs.map((log) => (
                <div key={log.id} className="border border-neutral-400 p-3">
                  <div className="text-sm mb-1">{log.content}</div>
                  <div className="text-xs text-neutral-600">{log.date}</div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Notes for Later */}
        <div className="p-4">
          <div className="border border-neutral-400 bg-neutral-100 px-2 py-1 mb-3 flex justify-between items-center">
            <h2 className="text-xs uppercase tracking-wide">Notes for Later</h2>
            <button
              onClick={() => setShowAddNote(!showAddNote)}
              className="text-xs uppercase underline"
            >
              + Add
            </button>
          </div>

          {showAddNote && (
            <div className="mb-3 space-y-2">
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                className="w-full border-2 border-neutral-800 px-3 py-2 text-sm h-20"
                placeholder="Enter note..."
              />
              <div className="flex gap-2">
                <button
                  onClick={handleAddNote}
                  className="flex-1 border border-neutral-800 bg-neutral-800 text-white px-3 py-1 text-xs uppercase"
                >
                  Save
                </button>
                <button
                  onClick={() => setShowAddNote(false)}
                  className="border border-neutral-400 px-3 py-1 text-xs uppercase"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {trackNotes.length === 0 ? (
              <div className="border border-neutral-300 p-3 text-sm text-neutral-500 text-center">
                No notes yet
              </div>
            ) : (
              trackNotes.map((note) => (
                <div key={note.id} className="border border-neutral-400 p-3">
                  <div className="text-sm">{note.content}</div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Annotation */}
        <div className="p-4 border-t border-neutral-300 mt-8">
          <p className="text-xs text-neutral-500 text-center">
            [WIREFRAME] Track Detail View
          </p>
        </div>
      </div>
    </div>
  );
}