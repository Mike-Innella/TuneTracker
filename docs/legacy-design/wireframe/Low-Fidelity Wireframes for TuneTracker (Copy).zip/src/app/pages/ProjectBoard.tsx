import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp, Stage } from '../context/AppContext';

const stages: Stage[] = ['Idea', 'Draft', 'Mix', 'Master', 'Released'];

export default function ProjectBoard() {
  const { projectId } = useParams();
  const { projects, tracks, addTrack, updateTrack } = useApp();
  const navigate = useNavigate();

  const project = projects.find(p => p.id === projectId);
  const projectTracks = tracks.filter(t => t.projectId === projectId);

  const [showAddTrack, setShowAddTrack] = useState<Stage | null>(null);
  const [newTrackTitle, setNewTrackTitle] = useState('');

  const handleAddTrack = (stage: Stage) => {
    if (newTrackTitle.trim() && projectId) {
      addTrack({
        title: newTrackTitle,
        stage,
        projectId,
      });
      setNewTrackTitle('');
      setShowAddTrack(null);
    }
  };

  const handleDragStart = (e: React.DragEvent, trackId: string) => {
    e.dataTransfer.setData('trackId', trackId);
  };

  const handleDrop = (e: React.DragEvent, stage: Stage) => {
    e.preventDefault();
    const trackId = e.dataTransfer.getData('trackId');
    updateTrack(trackId, { stage });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Fixed Header */}
      <div className="w-full bg-white border-b-2 border-neutral-800 p-4 sticky top-0 z-10">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="border border-neutral-400 px-3 py-1 text-xs uppercase"
            >
              ← Back
            </button>
            <h1 className="text-lg uppercase tracking-wide">{project.title}</h1>
          </div>
          <button
            onClick={() => navigate(`/project/${projectId}/public`)}
            className="border border-neutral-400 px-3 py-1 text-xs uppercase"
          >
            Public View
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="overflow-x-auto">
        <div className="inline-flex min-w-full p-4 gap-4">
          {stages.map((stage) => {
            const stageTracks = projectTracks.filter(t => t.stage === stage);

            return (
              <div
                key={stage}
                className="w-64 flex-shrink-0"
                onDrop={(e) => handleDrop(e, stage)}
                onDragOver={handleDragOver}
              >
                {/* Column Header */}
                <div className="border-2 border-neutral-800 bg-white p-3 mb-3">
                  <h2 className="uppercase tracking-wide text-sm text-center">
                    {stage}
                  </h2>
                  <div className="border-t border-neutral-400 mt-2 pt-2 text-center text-xs text-neutral-600">
                    {stageTracks.length} {stageTracks.length === 1 ? 'track' : 'tracks'}
                  </div>
                </div>

                {/* Track Cards */}
                <div className="space-y-2 min-h-[200px]">
                  {stageTracks.map((track) => (
                    <div
                      key={track.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, track.id)}
                      onClick={() => navigate(`/project/${projectId}/track/${track.id}`)}
                      className="border-2 border-neutral-400 bg-white p-3 cursor-move hover:border-neutral-800"
                    >
                      <div className="uppercase text-sm">{track.title}</div>
                      {track.bpm && (
                        <div className="mt-2 text-xs text-neutral-600">
                          {track.bpm} BPM | {track.key}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Add Track Button */}
                <div className="mt-3">
                  {showAddTrack === stage ? (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={newTrackTitle}
                        onChange={(e) => setNewTrackTitle(e.target.value)}
                        className="w-full border-2 border-neutral-800 px-3 py-2 text-sm"
                        placeholder="Track title"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddTrack(stage);
                          if (e.key === 'Escape') setShowAddTrack(null);
                        }}
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleAddTrack(stage)}
                          className="flex-1 border border-neutral-800 bg-neutral-800 text-white px-3 py-1 text-xs uppercase"
                        >
                          Add
                        </button>
                        <button
                          onClick={() => setShowAddTrack(null)}
                          className="border border-neutral-400 px-3 py-1 text-xs uppercase"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowAddTrack(stage)}
                      className="w-full border border-neutral-400 px-3 py-2 text-xs uppercase hover:border-neutral-800"
                    >
                      + Add Track
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Annotation */}
      <div className="p-4 border-t border-neutral-300 mt-8 bg-white">
        <p className="text-xs text-neutral-500 text-center max-w-[1440px] mx-auto">
          [WIREFRAME] Project Board - Kanban View (Drag tracks between columns)
        </p>
      </div>
    </div>
  );
}