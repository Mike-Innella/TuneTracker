import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';

export default function ProjectForm() {
  const { projectId } = useParams();
  const { projects, addProject, updateProject } = useApp();
  const navigate = useNavigate();

  const existingProject = projectId ? projects.find(p => p.id === projectId) : null;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(false);

  useEffect(() => {
    if (existingProject) {
      setTitle(existingProject.title);
      setDescription(existingProject.description);
      setIsPublic(existingProject.isPublic);
    }
  }, [existingProject]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (projectId && existingProject) {
      updateProject(projectId, { title, description, isPublic });
    } else {
      addProject({ title, description, isPublic });
    }
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="w-full max-w-[390px] mx-auto bg-white min-h-screen border-x-2 border-neutral-300">
        {/* Header */}
        <div className="border-b-2 border-neutral-800 p-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/dashboard')}
              className="border border-neutral-400 px-3 py-1 text-xs uppercase"
            >
              ← Back
            </button>
            <h1 className="text-lg uppercase tracking-wide">
              {projectId ? 'Edit Project' : 'New Project'}
            </h1>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-6">
          {/* Project Title */}
          <div className="space-y-2">
            <div className="border border-neutral-400 bg-neutral-100 px-2 py-1">
              <label className="text-xs uppercase tracking-wide">Project Title</label>
            </div>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border-2 border-neutral-800 px-4 py-3 bg-white"
              placeholder="Enter project title"
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <div className="border border-neutral-400 bg-neutral-100 px-2 py-1">
              <label className="text-xs uppercase tracking-wide">Description</label>
            </div>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border-2 border-neutral-800 px-4 py-3 bg-white h-32"
              placeholder="Enter project description"
              required
            />
          </div>

          {/* Visibility Toggle */}
          <div className="space-y-2">
            <div className="border border-neutral-400 bg-neutral-100 px-2 py-1">
              <label className="text-xs uppercase tracking-wide">Visibility</label>
            </div>
            <div className="border-2 border-neutral-800 p-4 flex items-center justify-between">
              <span className="uppercase text-sm">
                {isPublic ? 'Public' : 'Private'}
              </span>
              <button
                type="button"
                onClick={() => setIsPublic(!isPublic)}
                className={`w-12 h-6 border-2 border-neutral-800 relative ${
                  isPublic ? 'bg-neutral-800' : 'bg-white'
                }`}
              >
                <div
                  className={`absolute top-0 w-5 h-5 border border-neutral-800 transition-all ${
                    isPublic ? 'right-0 bg-white' : 'left-0 bg-neutral-800'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Save Button */}
          <button
            type="submit"
            className="w-full border-2 border-neutral-800 bg-neutral-800 text-white px-4 py-3 uppercase tracking-wide"
          >
            Save Project
          </button>
        </form>

        {/* Annotation */}
        <div className="p-4 border-t border-neutral-300 mt-8">
          <p className="text-xs text-neutral-500 text-center">
            [WIREFRAME] Create / Edit Project
          </p>
        </div>
      </div>
    </div>
  );
}