import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-4">
      <div className="w-full max-w-[390px] mx-auto">
        {/* Wireframe Container */}
        <div className="border-2 border-neutral-800 bg-white p-8">
          {/* App Name */}
          <div className="mb-12">
            <div className="border-2 border-neutral-400 p-4 text-center">
              <h1 className="text-xl uppercase tracking-wide">TuneTracker</h1>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Input */}
            <div className="space-y-2">
              <div className="border border-neutral-400 bg-neutral-100 px-2 py-1">
                <label className="text-xs uppercase tracking-wide">Email</label>
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border-2 border-neutral-800 px-4 py-3 bg-white"
                placeholder="user@example.com"
                required
              />
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <div className="border border-neutral-400 bg-neutral-100 px-2 py-1">
                <label className="text-xs uppercase tracking-wide">Password</label>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border-2 border-neutral-800 px-4 py-3 bg-white"
                placeholder="••••••••"
                required
              />
            </div>

            {/* Login Button */}
            <button
              type="submit"
              className="w-full border-2 border-neutral-800 bg-neutral-800 text-white px-4 py-3 uppercase tracking-wide hover:bg-neutral-700"
            >
              {isRegister ? 'Create Account' : 'Login'}
            </button>

            {/* Toggle Link */}
            <div className="border border-neutral-400 p-3 text-center">
              <button
                type="button"
                onClick={() => setIsRegister(!isRegister)}
                className="text-sm underline"
              >
                {isRegister ? 'Already have an account? Login' : 'Create new account'}
              </button>
            </div>
          </form>

          {/* Annotation */}
          <div className="mt-8 border-t border-neutral-300 pt-4">
            <p className="text-xs text-neutral-500 text-center">
              [WIREFRAME] Login / Register Screen
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}