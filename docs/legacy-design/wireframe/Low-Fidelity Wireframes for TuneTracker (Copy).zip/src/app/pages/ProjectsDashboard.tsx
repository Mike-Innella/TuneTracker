import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';

export default function ProjectsDashboard() {
  const { projects, logout } = useApp();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="w-full max-w-[390px] mx-auto bg-white min-h-screen border-x-2 border-neutral-300">
        {/* Header */}
        <div className="border-b-2 border-neutral-800 p-4">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-lg uppercase tracking-wide">My Projects</h1>
            <button
              onClick={handleLogout}
              className="border border-neutral-400 px-3 py-1 text-xs uppercase"
            >
              Logout
            </button>
          </div>
        </div>

        {/* New Project Button */}
        <div className="p-4 border-b border-neutral-300">
          <button
            onClick={() => navigate('/project/new')}
            className="w-full border-2 border-neutral-800 bg-neutral-800 text-white px-4 py-3 uppercase tracking-wide"
          >
            + New Project
          </button>
        </div>

        {/* Projects List */}
        <div className="p-4 space-y-4">
          {projects.map((project) => (
            <div
              key={project.id}
              onClick={() => navigate(`/project/${project.id}/board`)}
              className="border-2 border-neutral-400 p-4 bg-white cursor-pointer hover:border-neutral-800"
            >
              {/* Project Title */}
              <div className="border-b border-neutral-300 pb-2 mb-3">
                <h2 className="uppercase tracking-wide">{project.title}</h2>
              </div>

              {/* Visibility Label */}
              <div className="flex gap-2 mb-2">
                <div className="border border-neutral-400 px-2 py-1 text-xs uppercase bg-neutral-100">
                  {project.isPublic ? 'Public' : 'Private'}
                </div>
              </div>

              {/* Last Updated */}
              <div className="text-sm text-neutral-600">
                Last updated: {project.lastUpdated}
              </div>

              {/* View Link */}
              <div className="mt-3 pt-3 border-t border-neutral-200">
                <span className="text-xs uppercase underline">View Project →</span>
              </div>
            </div>
          ))}
        </div>

        {/* Annotation */}
        <div className="p-4 border-t border-neutral-300 mt-8">
          <p className="text-xs text-neutral-500 text-center">
            [WIREFRAME] Projects Dashboard
          </p>
        </div>
      </div>
    </div>
  );
}