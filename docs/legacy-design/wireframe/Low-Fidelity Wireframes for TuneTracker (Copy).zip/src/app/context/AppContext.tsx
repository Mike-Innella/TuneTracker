import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Stage = 'Idea' | 'Draft' | 'Mix' | 'Master' | 'Released';

export interface Track {
  id: string;
  title: string;
  stage: Stage;
  bpm?: number;
  key?: string;
  projectId: string;
}

export interface SessionLog {
  id: string;
  trackId: string;
  content: string;
  date: string;
}

export interface Note {
  id: string;
  trackId: string;
  content: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  isPublic: boolean;
  lastUpdated: string;
  ownerId: string;
}

export interface Comment {
  id: string;
  projectId: string;
  author: string;
  content: string;
  date: string;
}

export interface ProjectLike {
  projectId: string;
  userId: string;
}

export interface Rating {
  projectId: string;
  userId: string;
  rating: number;
}

interface AppContextType {
  isLoggedIn: boolean;
  currentUserId: string;
  login: (email: string, password: string) => void;
  logout: () => void;
  projects: Project[];
  tracks: Track[];
  sessionLogs: SessionLog[];
  notes: Note[];
  comments: Comment[];
  likes: ProjectLike[];
  ratings: Rating[];
  addProject: (project: Omit<Project, 'id' | 'lastUpdated' | 'ownerId'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  addTrack: (track: Omit<Track, 'id'>) => void;
  updateTrack: (id: string, updates: Partial<Track>) => void;
  addSessionLog: (log: Omit<SessionLog, 'id' | 'date'>) => void;
  addNote: (note: Omit<Note, 'id'>) => void;
  addComment: (comment: Omit<Comment, 'id' | 'date'>) => void;
  toggleLike: (projectId: string) => void;
  addRating: (projectId: string, rating: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUserId] = useState('user-1');

  // Mock data
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 'proj-1',
      title: 'Summer Album 2026',
      description: 'Collection of summer vibes tracks',
      isPublic: true,
      lastUpdated: '2026-02-08',
      ownerId: 'user-1',
    },
    {
      id: 'proj-2',
      title: 'Client Work - Brand X',
      description: 'Commercial project for Brand X',
      isPublic: false,
      lastUpdated: '2026-02-05',
      ownerId: 'user-1',
    },
    {
      id: 'proj-3',
      title: 'Experimental Beats',
      description: 'Testing new production techniques',
      isPublic: true,
      lastUpdated: '2026-01-28',
      ownerId: 'user-1',
    },
  ]);

  const [tracks, setTracks] = useState<Track[]>([
    { id: 'track-1', title: 'Sunset Drive', stage: 'Master', bpm: 120, key: 'Am', projectId: 'proj-1' },
    { id: 'track-2', title: 'Beach Vibes', stage: 'Mix', bpm: 110, key: 'G', projectId: 'proj-1' },
    { id: 'track-3', title: 'Ocean Waves', stage: 'Idea', bpm: 95, key: 'C', projectId: 'proj-1' },
    { id: 'track-4', title: 'Brand Intro', stage: 'Released', bpm: 128, key: 'Dm', projectId: 'proj-2' },
    { id: 'track-5', title: 'Product Theme', stage: 'Draft', bpm: 115, key: 'F', projectId: 'proj-2' },
  ]);

  const [sessionLogs, setSessionLogs] = useState<SessionLog[]>([
    { id: 'log-1', trackId: 'track-1', content: 'Added reverb to vocals', date: '2026-02-10' },
    { id: 'log-2', trackId: 'track-1', content: 'Adjusted bass EQ', date: '2026-02-09' },
    { id: 'log-3', trackId: 'track-2', content: 'Recorded guitar layers', date: '2026-02-08' },
  ]);

  const [notes, setNotes] = useState<Note[]>([
    { id: 'note-1', trackId: 'track-1', content: 'Try different snare sample' },
    { id: 'note-2', trackId: 'track-1', content: 'Add bridge section' },
    { id: 'note-3', trackId: 'track-3', content: 'Experiment with tempo automation' },
  ]);

  const [comments, setComments] = useState<Comment[]>([
    { id: 'com-1', projectId: 'proj-1', author: 'Alex M', content: 'Great work on this project!', date: '2026-02-09' },
    { id: 'com-2', projectId: 'proj-1', author: 'Jordan P', content: 'Love the beach vibes track', date: '2026-02-07' },
  ]);

  const [likes, setLikes] = useState<ProjectLike[]>([
    { projectId: 'proj-1', userId: 'user-2' },
    { projectId: 'proj-1', userId: 'user-3' },
  ]);

  const [ratings, setRatings] = useState<Rating[]>([
    { projectId: 'proj-1', userId: 'user-2', rating: 5 },
  ]);

  const login = (email: string, password: string) => {
    setIsLoggedIn(true);
  };

  const logout = () => {
    setIsLoggedIn(false);
  };

  const addProject = (project: Omit<Project, 'id' | 'lastUpdated' | 'ownerId'>) => {
    const newProject: Project = {
      ...project,
      id: `proj-${Date.now()}`,
      lastUpdated: new Date().toISOString().split('T')[0],
      ownerId: currentUserId,
    };
    setProjects([...projects, newProject]);
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects(projects.map(p => 
      p.id === id ? { ...p, ...updates, lastUpdated: new Date().toISOString().split('T')[0] } : p
    ));
  };

  const addTrack = (track: Omit<Track, 'id'>) => {
    const newTrack: Track = {
      ...track,
      id: `track-${Date.now()}`,
    };
    setTracks([...tracks, newTrack]);
  };

  const updateTrack = (id: string, updates: Partial<Track>) => {
    setTracks(tracks.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const addSessionLog = (log: Omit<SessionLog, 'id' | 'date'>) => {
    const newLog: SessionLog = {
      ...log,
      id: `log-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
    };
    setSessionLogs([...sessionLogs, newLog]);
  };

  const addNote = (note: Omit<Note, 'id'>) => {
    const newNote: Note = {
      ...note,
      id: `note-${Date.now()}`,
    };
    setNotes([...notes, newNote]);
  };

  const addComment = (comment: Omit<Comment, 'id' | 'date'>) => {
    const newComment: Comment = {
      ...comment,
      id: `com-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
    };
    setComments([...comments, newComment]);
  };

  const toggleLike = (projectId: string) => {
    const existingLike = likes.find(l => l.projectId === projectId && l.userId === currentUserId);
    if (existingLike) {
      setLikes(likes.filter(l => !(l.projectId === projectId && l.userId === currentUserId)));
    } else {
      setLikes([...likes, { projectId, userId: currentUserId }]);
    }
  };

  const addRating = (projectId: string, rating: number) => {
    const existingRating = ratings.find(r => r.projectId === projectId && r.userId === currentUserId);
    if (existingRating) {
      setRatings(ratings.map(r => 
        r.projectId === projectId && r.userId === currentUserId ? { ...r, rating } : r
      ));
    } else {
      setRatings([...ratings, { projectId, userId: currentUserId, rating }]);
    }
  };

  return (
    <AppContext.Provider
      value={{
        isLoggedIn,
        currentUserId,
        login,
        logout,
        projects,
        tracks,
        sessionLogs,
        notes,
        comments,
        likes,
        ratings,
        addProject,
        updateProject,
        addTrack,
        updateTrack,
        addSessionLog,
        addNote,
        addComment,
        toggleLike,
        addRating,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
